<?php

namespace Tests\Feature;

use App\User;
use Illuminate\Auth\Notifications\ResetPassword;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class UserTest extends TestCase
{


    //use RefreshDatabase;

    /*public function testHomePage() {
        $response = $this->get('/');

        $response->assertStatus(200);
    }

    public function testHeaders() {

        $response = $this
                    ->withHeaders([
                        "ExampleHeader" => "Example"
                    ])
                    ->json('POST','/users',['data' => "HelloWorld"]);

        $response
            ->assertStatus(200)
            ->assertJson([
                'status' => "success"
            ])
            ->assertHeader("ResponseHeader","Response")
        ;
    }*/

    /*public function testSession() {


        $user = factory(User::class)->create();


        $response = $this
            ->withSession([
                'user'=>"Ben"
            ])
            ->get('/users');

        $response
            ->assertStatus(200);
    }*/

    /*public function testFileUpload() {

        Storage::fake('files');

        $file = UploadedFile::fake()->image("picture.jpg");

        $response = $this->json("POST",'users',[
           'picture' =>  $file
        ]);
        $response->assertForbidden();
        Storage::disk('public')->assertExists($file->hashName());
        Storage::disk('public')->assertMissing($file->hashName());


    }*/


    //public function testDb() {

        /*$this->assertDatabaseMissing('users',[
            'email' => 'sdfsdfncorwin@example.org'
        ]);*/

        /*$user = DB::select("SELECT * FROM users WHERE id = 1");

        $modelUsers = User::find(1);

        $this->assertEquals($user[0]->name, $modelUsers->name);*/

        //$user = factory(User::class)->states("nameBen",'emailGoogle')->create();

        //$this->seed();
        //$user = factory(User::class)->state('nameBen')->create();

    //}


    //////////////////////////////////
    ///
    ///
    ///
    /*public function test_userCanViewLoginForm() {
        $response = $this->get('login');
        $response->assertSuccessful();
        $response->assertViewIs('auth.login');
    }

    public function test_userCanNotViewLoginWhenAuthentficated() {
        $user = factory(User::class)->create();

        $response = $this->actingAs($user)->get('login');
        $response->assertRedirect('/home');
    }

    public function test_userCanLoginWithCorrectCredentials() {
        $password = 'parol';

        $user = factory(User::class)->create([
            'password' => bcrypt($password)
        ]);

        $response = $this->post('/login',[
            'email' => $user->email,
            'password' =>$password,
        ]);

        $response->assertRedirect('/home');
        $this->assertAuthenticatedAs($user);
    }

    public function test_userCanNotLoginWithInCorrectCredentials() {
        $password = 'parol';

        $user = factory(User::class)->create([
            'password' => bcrypt($password)
        ]);

        $response = $this->from('/login')->post('/login',[
            'email' => $user->email,
            'password' =>"new password",
        ]);

        $response->assertRedirect('/login');
        $response->assertSessionHasErrors('email');
        $this->assertTrue(session()->hasOldInput('email'));
        $this->assertFalse(session()->hasOldInput('password'));
        $this->assertGuest();

    }*/

    public function test_userRememberMe() {

        $password = 'parol';
        $user = factory(User::class)->create([
            'id' => random_int(1,100),
            'password' => bcrypt($password)
        ]);

        $response = $this->post('/login',[
            'email' => $user->email,
            'password' =>$password,
            'remember' => 'on'
        ]);

        $response->assertRedirect('/home');
        $this->assertAuthenticatedAs($user);

        $response->assertCookie(Auth::guard()->getRecallerName(), vsprintf("%s|%s|%s",[
            $user->id,
            $user->getRememberToken(),
            $user->password
        ]));

    }

    public function test_userSendEmail() {
        Notification::fake();

        $user = factory(User::class)->create();

        $response = $this->post('/password/email',[
            'email' => $user->email
        ]);

        $token = DB::table('password_resets')->first();

        $this->assertNotNull($token);
        Notification::assertSentTo($user, ResetPassword::class, function ($notification, $channels) use ($token) {
            return Hash::check($notification->token, $token->token) === true;
        });




    }




}
