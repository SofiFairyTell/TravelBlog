@extends('layouts.app')

@section('content')
    <div class="container">

        <form>
            <div class="form-group">
                <label for="exampleInputEmail1">Search by name</label>
                <input type="text" name="search" class="form-control" id="search"  placeholder="Enter name">
            </div>

            <div class="form-group">
                <label for="exampleInputEmail1">Search by email</label>
                <input type="text" name="email" class="form-control" id="search"  placeholder="Enter name">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        <hr>
        <div>
            <h2>Users</h2>
            <ul>
            @foreach($users as $user)
               <li>{{$user->name}}</li>
            @endforeach
            </ul>
        </div>
    </div>
@endsection