<?php
/**
 * Created by PhpStorm.
 * User: Viktor
 * Date: 29.09.2019
 * Time: 22:51
 */

return [

    'page_title' => 'page title',

];