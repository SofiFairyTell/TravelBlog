<?php

use Faker\Generator as Faker;
use Illuminate\Support\Str;

$factory->define(App\User::class, function (Faker $faker) {
    return [
        'name' => $faker->name,
        'email' => $faker->unique()->safeEmail(),
        'created_at' => now(),
        'password' => bcrypt("12345"),
        'remember_token' => Str::random(10),


    ];
});


$factory->state(
    \App\User::class, 'nameBen', [
        'name' => "Ben"
    ]
);

$factory->state(
    \App\User::class, 'emailGoogle', [
        'email' => "admin@google.com"
    ]
);

$factory->afterMaking(\App\User::class, function($user, $faker) {
    echo "to do";
});

$factory->afterCreating(\App\User::class, function($user, $faker) {
    echo "to do create";
});

$factory->afterMakingState(\App\User::class,'nameBen', function($user, $faker) {
    echo "to do state";
});

$factory->afterCreatingState(\App\User::class,'nameBen' ,function($user, $faker) {
    echo "to do create state";
});