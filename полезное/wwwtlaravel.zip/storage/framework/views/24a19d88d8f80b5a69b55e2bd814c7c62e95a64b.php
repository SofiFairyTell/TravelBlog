<?php $__env->startSection('content'); ?>
    <div class="container">

        <form>
            <div class="form-group">
                <label for="exampleInputEmail1">Search by name</label>
                <input type="text" name="search" class="form-control" id="search"  placeholder="Enter name">
            </div>

            <div class="form-group">
                <label for="exampleInputEmail1">Search by email</label>
                <input type="text" name="email" class="form-control" id="search"  placeholder="Enter name">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        <hr>
        <div>
            <h2>Users</h2>
            <ul>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li><?php echo e($user->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>