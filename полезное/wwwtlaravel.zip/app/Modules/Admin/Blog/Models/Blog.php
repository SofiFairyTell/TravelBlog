<?php

namespace App\Modules\Admin\Blog\Models;

use Illuminate\Database\Eloquent\Model;

class Blog extends Model
{
    //
}
