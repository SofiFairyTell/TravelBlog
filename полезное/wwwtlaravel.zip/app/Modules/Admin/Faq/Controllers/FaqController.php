<?php
/**
 * Created by PhpStorm.
 * User: Viktor
 * Date: 29.09.2019
 * Time: 17:54
 */

namespace App\Modules\Admin\Faq\Controllers;


use App\Http\Controllers\Controller;

class FaqController extends Controller
{
     public function index() {
         dd('hello');
     }
}