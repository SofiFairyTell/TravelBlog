<?php

namespace App\Modules\Admin\Faq\Models;

use Illuminate\Database\Eloquent\Model;

class Faq extends Model
{
    //
}
